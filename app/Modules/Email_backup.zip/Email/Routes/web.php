<?php

Route::group(['prefix' => 'patient/bill', 'middleware' => 'auth'], function () {

    Route::get('/mail/view/{id}','MailController@mailView')->name('patient_bill_mail_send_view')->middleware('read_access');
    Route::post('mail/send/{id}', 'MailController@mailSend')->name('patient_bill_mail_send')->middleware('create_access');

    Route::get('/report/mail/view/{id}','MailController@reportMailView')->name('test_report_mail_send_view')->middleware('read_access');
    Route::post('report/send/{id}', 'MailController@reportMailSend')->name('test_report_mail_send')->middleware('create_access');

});




